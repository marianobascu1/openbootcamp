﻿

Console.WriteLine("Introduzca las horas: ");
string horas = Console.ReadLine();

Console.WriteLine("Introduzca los minutos:");
string minutos = Console.ReadLine();

Console.WriteLine("La hora introducida es :" + horas);
Console.WriteLine("La hora introducida es :" + minutos);
