﻿


using System.Net;

Console.WriteLine ("Introducie tu nombre:");    

string nombre = Console.ReadLine();

Console.WriteLine("Tu nombre es : " + nombre);


